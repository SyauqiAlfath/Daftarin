package PemogramanII;

public class Tugas2 {
    public static void main(String[] args) {
        String[][] mahasiswa = {{"uus", "syauqi", "akbar", "aqil", "aqila", "hafiz", "raihan", "khisyam", "andra", "azhar.m", "qalby", "haikal", "belitung", "Azhar.A", "akmal", "Renald", "dwi", "Anggoro", "najwa", "rahma", "ana", "salsa", "nisa", "anya", "adel", "aca", "hani", "putri", "kama"}, {"najwa", "rahma", "ana", "salsa", "nisa", "anya", "adel", "aca", "hani", "putri", "kama"}};
        for (int i = 0; i < mahasiswa.length; i++) {
            for (int j = 0; j < mahasiswa[i].length; j++) {
                System.out.println(mahasiswa[i][j]);
            }
        }
    }
}
