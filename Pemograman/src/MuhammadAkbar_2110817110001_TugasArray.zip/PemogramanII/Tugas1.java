package PemogramanII;
public class Tugas1 {
   public static void main(String[] args) {
     int[][] myNumbers = { {1, 2, 3, 4}, {5, 6, 7} };
//     for (int i = 0; i < myNumbers.length; ++i) {
//        for(int j = 2; j < 3; ++j) {
//           System.out.println(myNumbers[i][j]);
//        }
 // }
  for(int i =0; i<myNumbers.length; i++){
       for(int j = 0; j < myNumbers[i].length; j++) {
           if(myNumbers[i][j]==3 ||myNumbers[i][j]==7)
           System.out.println(myNumbers[i][j]);
        }
     }
   }
}

